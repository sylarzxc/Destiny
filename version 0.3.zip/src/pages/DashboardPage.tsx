import React from 'react'
import { CabinetApp } from '../components/CabinetApp'

export function DashboardPage() {
  return <CabinetApp />
}